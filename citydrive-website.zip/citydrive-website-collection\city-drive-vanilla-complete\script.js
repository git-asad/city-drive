// City Drive - Vanilla JavaScript Implementation
// Global variables
let currentUser = null;
let currentPage = 'home';

// Firebase imports (already loaded via CDN)
const { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged } = window.auth;
const { getFirestore, collection, doc, setDoc, getDoc, getDocs, updateDoc, query, where, orderBy, limit } = window.db;

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadPage('home');
});

// Initialize Firebase Auth state listener
function initializeApp() {
    onAuthStateChanged(window.auth, (user) => {
        if (user) {
            currentUser = user;
            updateUIForAuthenticatedUser(user);
            logAction('User authenticated', { uid: user.uid, email: user.email });
        } else {
            currentUser = null;
            updateUIForUnauthenticatedUser();
        }
    });
}

// Setup event listeners
function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Signup form
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup);
    }
}

// Navigation
function navigateTo(page) {
    currentPage = page;
    loadPage(page);
    window.history.pushState({ page }, page, `#${page}`);
}

// Load page content
async function loadPage(page) {
    const mainContent = document.getElementById('main-content');
    if (!mainContent) return;

    try {
        switch(page) {
            case 'home':
                mainContent.innerHTML = await renderHomePage();
                break;
            case 'cars':
                mainContent.innerHTML = await renderCarsPage();
                break;
            case 'dashboard':
                if (!currentUser) {
                    navigateTo('home');
                    return;
                }
                mainContent.innerHTML = await renderDashboardPage();
                break;
            case 'my-bookings':
                if (!currentUser) {
                    navigateTo('home');
                    return;
                }
                mainContent.innerHTML = await renderMyBookingsPage();
                break;
            case 'booking':
                mainContent.innerHTML = await renderBookingPage();
                break;
            default:
                mainContent.innerHTML = await renderHomePage();
        }
    } catch (error) {
        logError('Page load error', error);
        mainContent.innerHTML = '<div class="error">Error loading page. Please try again.</div>';
    }
}

// Authentication Functions
async function handleLogin(e) {
    e.preventDefault();

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const userCredential = await signInWithEmailAndPassword(window.auth, email, password);
        logAction('User login successful', { uid: userCredential.user.uid, email });
        closeModal('login-modal');
        navigateTo('home');
    } catch (error) {
        logError('Login failed', error);
        alert('Login failed: ' + error.message);
    }
}

async function handleSignup(e) {
    e.preventDefault();

    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const role = document.getElementById('signup-role').value;

    try {
        const userCredential = await createUserWithEmailAndPassword(window.auth, email, password);

        // Save user profile to Firestore
        await setDoc(doc(window.db, 'users', userCredential.user.uid), {
            name,
            email,
            role,
            createdAt: new Date(),
            uid: userCredential.user.uid
        });

        logAction('User registration successful', { uid: userCredential.user.uid, email, role });
        closeModal('signup-modal');
        navigateTo('home');
    } catch (error) {
        logError('Signup failed', error);
        alert('Signup failed: ' + error.message);
    }
}

async function logout() {
    try {
        await signOut(window.auth);
        logAction('User logout successful');
        navigateTo('home');
    } catch (error) {
        logError('Logout failed', error);
    }
}

// UI Update Functions
function updateUIForAuthenticatedUser(user) {
    document.getElementById('nav-auth').style.display = 'none';
    document.getElementById('nav-user').style.display = 'block';
    document.getElementById('user-name').textContent = user.displayName || user.email;
}

function updateUIForUnauthenticatedUser() {
    document.getElementById('nav-auth').style.display = 'block';
    document.getElementById('nav-user').style.display = 'none';
}

// Modal Functions
function showLoginModal() {
    document.getElementById('login-modal').style.display = 'block';
}

function showSignupModal() {
    document.getElementById('signup-modal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function switchToSignup() {
    closeModal('login-modal');
    showSignupModal();
}

function switchToLogin() {
    closeModal('signup-modal');
    showLoginModal();
}

// Page Render Functions
async function renderHomePage() {
    return `
        <section class="hero">
            <div class="hero-content">
                <h1>Find Your Perfect Car</h1>
                <p>Discover amazing cars for rent from trusted owners</p>
                <button class="btn-primary" onclick="navigateTo('cars')">Browse Cars</button>
            </div>
            <div class="hero-image">
                <img src="assets/main_car.png" alt="Car">
            </div>
        </section>

        <section class="features">
            <h2>Why Choose City Drive?</h2>
async function renderBookingPage() {
    // Get car ID from URL hash
    const hash = window.location.hash;
    const carId = hash.split('?car=')[1];

    if (!carId) {
        return '<div class="error">No car selected for booking</div>';
    }

    if (!currentUser) {
        showLoginModal();
        return '<div>Please login to book a car</div>';
    }

    try {
        const car = await getCarById(carId);
        if (!car) {
            return '<div class="error">Car not found</div>';
        }

        return '<div class="booking-page">' +
            '<h1>Book Your Car</h1>' +
            '<div class="car-summary">' +
                '<img src="' + (car.image || 'assets/main_car.png') + '" alt="' + car.brand + ' ' + car.model + '">' +
                '<div class="car-details">' +
                    '<h2>' + car.brand + ' ' + car.model + '</h2>' +
                    '<p class="price">$' + car.pricePerDay + '/day</p>' +
                    '<p class="location">' + car.location + '</p>' +
                '</div>' +
            '</div>' +
            '<form id="booking-form" class="booking-form">' +
                '<div class="form-section">' +
                    '<h3>Rental Details</h3>' +
                    '<div class="form-row">' +
                        '<div class="form-group">' +
                            '<label>Pickup Date *</label>' +
                            '<input type="date" id="pickup-date" required>' +
                        '</div>' +
                        '<div class="form-group">' +
                            '<label>Return Date *</label>' +
                            '<input type="date" id="return-date" required>' +
                        '</div>' +
                    '</div>' +
                    '<div class="form-group">' +
                        '<label>Pickup Location *</label>' +
                        '<input type="text" id="pickup-location" placeholder="Enter pickup location" required>' +
                    '</div>' +
                '</div>' +
                '<div class="form-section">' +
                    '<h3>Personal Information</h3>' +
                    '<div class="form-row">' +
                        '<div class="form-group">' +
                            '<label>First Name *</label>' +
                            '<input type="text" id="first-name" required>' +
                        '</div>' +
                        '<div class="form-group">' +
                            '<label>Last Name *</label>' +
                            '<input type="text" id="last-name" required>' +
                        '</div>' +
                    '</div>' +
                    '<div class="form-row">' +
                        '<div class="form-group">' +
                            '<label>Email *</label>' +
                            '<input type="email" id="email" required>' +
                        '</div>' +
                        '<div class="form-group">' +
                            '<label>Phone *</label>' +
                            '<input type="tel" id="phone" required>' +
                        '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="form-section">' +
                    '<h3>Additional Options</h3>' +
                    '<label class="checkbox-label">' +
                        '<input type="checkbox" id="insurance"> Add insurance ($15/day)' +
                    '</label>' +
                    '<div class="form-group">' +
                        '<label>Special Requests</label>' +
                        '<textarea id="special-requests" placeholder="Any special requests..."></textarea>' +
                    '</div>' +
                '</div>' +
                '<div class="booking-summary">' +
                    '<h3>Booking Summary</h3>' +
                    '<div id="price-breakdown">' +
                        '<p>Calculating...</p>' +
                    '</div>' +
                '</div>' +
                '<div class="form-actions">' +
                    '<button type="button" onclick="navigateTo(\'cars\')" class="btn-secondary">Cancel</button>' +
                    '<button type="submit" class="btn-primary">Confirm Booking</button>' +
                '</div>' +
            '</form>' +
        '</div>';
    } catch (error) {
        logError('Error loading booking page', error);
        return '<div class="error">Error loading booking page</div>';
    }
}

// Helper function to get car by ID
async function getCarById(carId) {
    try {
        const carDoc = await getDoc(doc(window.db, 'cars', carId));
        if (carDoc.exists()) {
            return { id: carDoc.id, ...carDoc.data() };
        }
        return null;
    } catch (error) {
        logError('Error fetching car', error);
        return null;
    }
}

// Add booking form event listener
document.addEventListener('DOMContentLoaded', function() {
    // ... existing code ...

    // Booking form submission
    document.addEventListener('submit', async function(e) {
        if (e.target.id === 'booking-form') {
            e.preventDefault();
            await handleBookingSubmit();
        }
    });

    // Update price calculation when dates change
    document.addEventListener('change', function(e) {
        if (e.target.id === 'pickup-date' || e.target.id === 'return-date' || e.target.id === 'insurance') {
            updatePriceBreakdown();
        }
    });
});

async function handleBookingSubmit() {
    const formData = {
        pickupDate: document.getElementById('pickup-date').value,
        returnDate: document.getElementById('return-date').value,
        pickupLocation: document.getElementById('pickup-location').value,
        firstName: document.getElementById('first-name').value,
        lastName: document.getElementById('last-name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        insurance: document.getElementById('insurance').checked,
        specialRequests: document.getElementById('special-requests').value
    };

    // Validation
    if (!formData.pickupDate || !formData.returnDate) {
        alert('Please select pickup and return dates');
        return;
    }

    const pickupDate = new Date(formData.pickupDate);
    const returnDate = new Date(formData.returnDate);

    if (returnDate <= pickupDate) {
        alert('Return date must be after pickup date');
        return;
    }

    try {
        // Get car details
        const hash = window.location.hash;
        const carId = hash.split('?car=')[1];
        const car = await getCarById(carId);

        // Calculate pricing
        const days = Math.ceil((returnDate - pickupDate) / (1000 * 60 * 60 * 24));
        const basePrice = days * car.pricePerDay;
        const insuranceCost = formData.insurance ? days * 15 : 0;
        const totalPrice = basePrice + insuranceCost;

        // Create booking
        const booking = {
            car: car,
            customerId: currentUser.uid,
            customerInfo: {
                firstName: formData.firstName,
                lastName: formData.lastName,
                email: formData.email,
                phone: formData.phone
            },
            pickupDate: formData.pickupDate,
            returnDate: formData.returnDate,
            pickupLocation: formData.pickupLocation,
            returnLocation: formData.pickupLocation,
            days: days,
            insurance: formData.insurance,
            specialRequests: formData.specialRequests,
            price: totalPrice,
            status: 'pending',
            createdAt: new Date()
        };

        // Save to Firestore
        const docRef = await setDoc(doc(collection(window.db, 'bookings')), booking);

        logAction('Booking created', { bookingId: docRef.id, carId });
        alert('Booking submitted successfully! The owner will review your request.');
        navigateTo('my-bookings');

    } catch (error) {
        logError('Error creating booking', error);
        alert('Error creating booking. Please try again.');
    }
}

function updatePriceBreakdown() {
    const pickupDate = document.getElementById('pickup-date')?.value;
    const returnDate = document.getElementById('return-date')?.value;
    const insurance = document.getElementById('insurance')?.checked;

    if (!pickupDate || !returnDate) return;

    const start = new Date(pickupDate);
    const end = new Date(returnDate);

    if (end <= start) return;

    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    const hash = window.location.hash;
    const carId = hash.split('?car=')[1];

    // For demo purposes, assume $50/day if car not loaded
    const pricePerDay = 50; // In real app, get from car data
    const basePrice = days * pricePerDay;
    const insuranceCost = insurance ? days * 15 : 0;
    const total = basePrice + insuranceCost;

    const breakdown = document.getElementById('price-breakdown');
    if (breakdown) {
        breakdown.innerHTML = '<div class="price-row">' +
            '<span>Rental (' + days + ' days):</span>' +
            '<span>$' + basePrice + '</span>' +
        '</div>' +
        (insurance ? '<div class="price-row"><span>Insurance (' + days + ' days):</span><span>$' + insuranceCost + '</span></div>' : '') +
        '<div class="price-row total">' +
            '<span>Total:</span>' +
            '<span>$' + total + '</span>' +
        '</div>';
    }
}
            <div class="features-grid">
                <div class="feature-card">
                    <img src="assets/car_icon.svg" alt="Wide Selection">
                    <h3>Wide Selection</h3>
                    <p>Choose from hundreds of cars</p>
                </div>
                <div class="feature-card">
                    <img src="assets/location_icon.svg" alt="Flexible Pickup">
                    <h3>Flexible Pickup</h3>
                    <p>Convenient locations</p>
                </div>
                <div class="feature-card">
                    <img src="assets/check_icon.svg" alt="Trusted Owners">
                    <h3>Trusted Owners</h3>
                    <p>Verified car owners</p>
                </div>
            </div>
        </section>

        <section class="cta">
            <h2>Ready to Start Your Journey?</h2>
            <p>Join thousands of satisfied customers</p>
            <button class="btn-primary" onclick="showSignupModal()">Get Started</button>
        </section>
    `;
}

async function renderCarsPage() {
    try {
        const cars = await getCars();
        const carsHTML = cars.map(car => `
            <div class="car-card">
                <img src="${car.image || 'assets/main_car.png'}" alt="${car.brand} ${car.model}">
                <div class="car-info">
                    <h3>${car.brand} ${car.model}</h3>
                    <p class="price">$${car.pricePerDay}/day</p>
                    <p class="location">${car.location}</p>
                    <button class="btn-primary" onclick="bookCar('${car.id}')">Book Now</button>
                </div>
            </div>
        `).join('');

        return `
            <div class="cars-page">
                <h1>Available Cars</h1>
                <div class="cars-grid">
                    ${carsHTML}
                </div>
            </div>
        `;
    } catch (error) {
        logError('Error loading cars', error);
        return '<div class="error">Error loading cars. Please try again.</div>';
    }
}

async function renderDashboardPage() {
    if (!currentUser) return '<div>Please login to access dashboard</div>';

    try {
        const userDoc = await getDoc(doc(window.db, 'users', currentUser.uid));
        const userData = userDoc.data();

        if (userData.role === 'owner') {
            return await renderOwnerDashboard();
        } else {
            return await renderCustomerDashboard();
        }
    } catch (error) {
        logError('Error loading dashboard', error);
        return '<div class="error">Error loading dashboard</div>';
    }
}

async function renderOwnerDashboard() {
    const bookings = await getOwnerBookings();
    const cars = await getOwnerCars();
    const stats = calculateOwnerStats(bookings);

    return `
        <div class="dashboard">
            <h1>Owner Dashboard</h1>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Cars</h3>
                    <p>${cars.length}</p>
                </div>
                <div class="stat-card">
                    <h3>Total Bookings</h3>
                    <p>${stats.totalBookings}</p>
                </div>
                <div class="stat-card">
                    <h3>Pending Bookings</h3>
                    <p>${stats.pendingBookings}</p>
                </div>
                <div class="stat-card">
                    <h3>Revenue</h3>
                    <p>$${stats.revenue}</p>
                </div>
            </div>

            <div class="dashboard-actions">
                <button class="btn-primary" onclick="addNewCar()">Add New Car</button>
                <button class="btn-secondary" onclick="manageCars()">Manage Cars</button>
            </div>

            <div class="recent-bookings">
                <h2>Recent Bookings</h2>
                <div class="bookings-list">
                    ${bookings.slice(0, 5).map(booking => `
                        <div class="booking-item">
                            <p>${booking.car.brand} ${booking.car.model}</p>
                            <p>Status: ${booking.status}</p>
                            <p>$${booking.price}</p>
                            ${booking.status === 'pending' ? `
                                <button onclick="acceptBooking('${booking.id}')">Accept</button>
                                <button onclick="rejectBooking('${booking.id}')">Reject</button>
                            ` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;
}

async function renderCustomerDashboard() {
    const bookings = await getCustomerBookings();
    const stats = calculateCustomerStats(bookings);

    return `
        <div class="dashboard">
            <h1>Customer Dashboard</h1>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Bookings</h3>
                    <p>${stats.totalBookings}</p>
                </div>
                <div class="stat-card">
                    <h3>Active Bookings</h3>
                    <p>${stats.activeBookings}</p>
                </div>
                <div class="stat-card">
                    <h3>Total Spent</h3>
                    <p>$${stats.totalSpent}</p>
                </div>
            </div>

            <div class="dashboard-actions">
                <button class="btn-primary" onclick="navigateTo('cars')">Browse Cars</button>
                <button class="btn-secondary" onclick="navigateTo('my-bookings')">View All Bookings</button>
            </div>
        </div>
    `;
}

async function renderMyBookingsPage() {
    if (!currentUser) return '<div>Please login to view bookings</div>';

    try {
        const bookings = await getCustomerBookings();
        const bookingsHTML = bookings.map(booking => `
            <div class="booking-card">
                <img src="${booking.car.image || 'assets/main_car.png'}" alt="${booking.car.brand} ${booking.car.model}">
                <div class="booking-info">
                    <h3>${booking.car.brand} ${booking.car.model}</h3>
                    <p>Dates: ${formatDate(booking.pickupDate)} - ${formatDate(booking.returnDate)}</p>
                    <p>Status: <span class="status-${booking.status}">${booking.status}</span></p>
                    <p>Total: $${booking.price}</p>
                    ${booking.status === 'pending' ? '<button onclick="cancelBooking(\'' + booking.id + '\')">Cancel</button>' : ''}
                </div>
            </div>
        `).join('');

        return `
            <div class="my-bookings">
                <h1>My Bookings</h1>
                <div class="bookings-container">
                    ${bookingsHTML || '<p>No bookings found</p>'}
                </div>
            </div>
        `;
    } catch (error) {
        logError('Error loading bookings', error);
        return '<div class="error">Error loading bookings</div>';
    }
}

// Firestore Functions
async function getCars() {
    try {
        const carsRef = collection(window.db, 'cars');
        const querySnapshot = await getDocs(carsRef);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        logError('Error fetching cars', error);
        return [];
    }
}

async function getOwnerBookings() {
    if (!currentUser) return [];
    try {
        const bookingsRef = collection(window.db, 'bookings');
        const q = query(bookingsRef, where('ownerId', '==', currentUser.uid));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        logError('Error fetching owner bookings', error);
        return [];
    }
}

async function getCustomerBookings() {
    if (!currentUser) return [];
    try {
        const bookingsRef = collection(window.db, 'bookings');
        const q = query(bookingsRef, where('customerId', '==', currentUser.uid));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        logError('Error fetching customer bookings', error);
        return [];
    }
}

async function getOwnerCars() {
    if (!currentUser) return [];
    try {
        const carsRef = collection(window.db, 'cars');
        const q = query(carsRef, where('ownerId', '==', currentUser.uid));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
        logError('Error fetching owner cars', error);
        return [];
    }
}

// Booking Functions
function bookCar(carId) {
    if (!currentUser) {
        showLoginModal();
        return;
    }
    // Navigate to booking page with car ID
    window.location.hash = `booking?car=${carId}`;
    loadPage('booking');
// Sample Data Initialization (run this once to populate Firestore)
async function initializeSampleData() {
    try {
        logAction('Initializing sample data');

        // Sample cars data
        const sampleCars = [
            {
                brand: 'BMW',
                model: 'X5',
                name: 'BMW X5 2023',
                pricePerDay: 85,
                location: 'New York, NY',
                image: 'assets/bmw_new.png',
                category: 'SUV',
                year: 2023,
                fuel_type: 'Gasoline',
                transmission: 'Automatic',
                seating_capacity: 5,
                ownerId: 'sample-owner-id', // Will be updated when owner signs up
                isVisible: true,
                createdAt: new Date()
            },
            {
                brand: 'Mercedes',
                model: 'C-Class',
                name: 'Mercedes C-Class 2022',
                pricePerDay: 75,
                location: 'Los Angeles, CA',
                image: 'assets/main_car.png',
                category: 'Sedan',
                year: 2022,
                fuel_type: 'Gasoline',
                transmission: 'Automatic',
                seating_capacity: 5,
                ownerId: 'sample-owner-id',
                isVisible: true,
                createdAt: new Date()
            },
            {
                brand: 'Audi',
                model: 'Q7',
                name: 'Audi Q7 2023',
                pricePerDay: 90,
                location: 'Chicago, IL',
                image: 'assets/car_image1.png',
                category: 'SUV',
                year: 2023,
                fuel_type: 'Diesel',
                transmission: 'Automatic',
                seating_capacity: 7,
                ownerId: 'sample-owner-id',
                isVisible: true,
                createdAt: new Date()
            }
        ];

        // Add sample cars to Firestore
        for (const car of sampleCars) {
            await setDoc(doc(collection(window.db, 'cars')), car);
        }

        logAction('Sample data initialized successfully');
        console.log('✅ Sample data added to Firestore');
    } catch (error) {
        logError('Error initializing sample data', error);
    }
}

// Uncomment the line below to initialize sample data (run once)
// initializeSampleData();

// FUTURE ENHANCEMENT: Payment Integration
/*
async function processPayment(bookingData, paymentMethod) {
    // TODO: Integrate with Stripe/PayPal
    // This would handle payment processing before creating booking

    switch(paymentMethod) {
        case 'stripe':
            // Implement Stripe payment
            console.log('Processing Stripe payment...');
            break;
        case 'paypal':
            // Implement PayPal payment
            console.log('Processing PayPal payment...');
            break;
        default:
            console.log('Processing bank transfer...');
    }

    // Return payment result
    return { success: true, transactionId: 'txn_' + Date.now() };
}
*/

// FUTURE ENHANCEMENT: Image Upload System
/*
async function uploadCarImage(file) {
    // TODO: Implement Firebase Storage integration
    // This would upload car images and return download URLs

    const storageRef = ref(storage, 'car-images/' + file.name);
    const uploadTask = uploadBytesResumable(storageRef, file);

    return new Promise((resolve, reject) => {
        uploadTask.on('state_changed',
            (snapshot) => {
                // Progress monitoring
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                console.log('Upload progress: ' + progress + '%');
            },
            (error) => {
                logError('Image upload failed', error);
                reject(error);
            },
            () => {
                getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
                    resolve(downloadURL);
                });
            }
        );
    });
}
*/

// FUTURE ENHANCEMENT: Review System
/*
async function submitReview(carId, reviewData) {
    // TODO: Implement review system
    // This would allow customers to leave reviews for cars

    const review = {
        carId,
        customerId: currentUser.uid,
        rating: reviewData.rating,
        comment: reviewData.comment,
        createdAt: new Date(),
        helpful: 0
    };

    await setDoc(doc(collection(window.db, 'reviews')), review);
    logAction('Review submitted', { carId });
}

async function getCarReviews(carId) {
    // TODO: Get reviews for a specific car
    const q = query(collection(window.db, 'reviews'),
                    where('carId', '==', carId),
                    orderBy('createdAt', 'desc'));

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}
*/

// FUTURE ENHANCEMENT: Advanced Search and Filtering
/*
async function searchCars(filters) {
    // TODO: Implement advanced search with multiple filters
    // Filters: location, price range, category, dates, etc.

    let q = collection(window.db, 'cars');

    // Apply filters
    if (filters.location) {
        q = query(q, where('location', '==', filters.location));
    }

    if (filters.category) {
        q = query(q, where('category', '==', filters.category));
    }

    if (filters.maxPrice) {
        q = query(q, where('pricePerDay', '<=', filters.maxPrice));
    }

    // Add date availability checking logic here

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}
*/

// FUTURE ENHANCEMENT: Email Notifications
/*
async function sendBookingNotification(booking, type) {
    // TODO: Integrate with email service (SendGrid, Firebase Functions, etc.)
    // Types: booking_created, booking_confirmed, booking_cancelled, etc.

    const emailData = {
        to: booking.customerInfo.email,
        subject: `Booking ${type.replace('_', ' ').toUpperCase()}`,
        template: type,
        data: booking
    };

    // Send email via your email service
    console.log('Sending email notification:', emailData);
    logAction('Email notification sent', { type, bookingId: booking.id });
}
*/

// FUTURE ENHANCEMENT: Admin Panel Functions
/*
async function getPlatformStats() {
    // TODO: Admin function to get platform-wide statistics
    const stats = {
        totalUsers: 0,
        totalCars: 0,
        totalBookings: 0,
        totalRevenue: 0
    };

    // Get counts from Firestore
    const usersSnapshot = await getDocs(collection(window.db, 'users'));
    stats.totalUsers = usersSnapshot.size;

    const carsSnapshot = await getDocs(collection(window.db, 'cars'));
    stats.totalCars = carsSnapshot.size;

    const bookingsSnapshot = await getDocs(collection(window.db, 'bookings'));
    stats.totalBookings = bookingsSnapshot.size;

    // Calculate revenue from confirmed bookings
    const confirmedBookings = bookingsSnapshot.docs.filter(doc => doc.data().status === 'confirmed');
    stats.totalRevenue = confirmedBookings.reduce((sum, doc) => sum + doc.data().price, 0);

    return stats;
}
*/

// Make initializeSampleData available globally for testing
window.initializeSampleData = initializeSampleData;
}

async function acceptBooking(bookingId) {
    try {
        await updateDoc(doc(window.db, 'bookings', bookingId), {
            status: 'confirmed',
            updatedAt: new Date()
        });
        logAction('Booking accepted', { bookingId });
        alert('Booking accepted successfully!');
        loadPage('dashboard');
    } catch (error) {
        logError('Error accepting booking', error);
        alert('Error accepting booking');
    }
}

async function rejectBooking(bookingId) {
    try {
        await updateDoc(doc(window.db, 'bookings', bookingId), {
            status: 'cancelled',
            updatedAt: new Date()
        });
        logAction('Booking rejected', { bookingId });
        alert('Booking rejected');
        loadPage('dashboard');
    } catch (error) {
        logError('Error rejecting booking', error);
        alert('Error rejecting booking');
    }
}

async function cancelBooking(bookingId) {
    if (confirm('Are you sure you want to cancel this booking?')) {
        try {
            await updateDoc(doc(window.db, 'bookings', bookingId), {
                status: 'cancelled',
                updatedAt: new Date()
            });
            logAction('Booking cancelled by customer', { bookingId });
            alert('Booking cancelled successfully!');
            loadPage('my-bookings');
        } catch (error) {
            logError('Error cancelling booking', error);
            alert('Error cancelling booking');
        }
    }
}

// Utility Functions
function calculateOwnerStats(bookings) {
    return {
        totalBookings: bookings.length,
        pendingBookings: bookings.filter(b => b.status === 'pending').length,
        revenue: bookings.filter(b => b.status === 'confirmed').reduce((sum, b) => sum + b.price, 0)
    };
}

function calculateCustomerStats(bookings) {
    return {
        totalBookings: bookings.length,
        activeBookings: bookings.filter(b => b.status === 'confirmed').length,
        totalSpent: bookings.reduce((sum, b) => sum + b.price, 0)
    };
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString();
}

// Logging Functions
function logAction(action, details = {}) {
    const logEntry = {
        timestamp: new Date(),
        action,
        userId: currentUser?.uid,
        details,
        page: currentPage
    };
    console.log('Action logged:', logEntry);

    // In production, send to logging service
    // For now, store in localStorage for debugging
    const logs = JSON.parse(localStorage.getItem('app_logs') || '[]');
    logs.push(logEntry);
    localStorage.setItem('app_logs', JSON.stringify(logs.slice(-100))); // Keep last 100 logs
}

function logError(context, error) {
    const errorEntry = {
        timestamp: new Date(),
        context,
        error: error.message,
        stack: error.stack,
        userId: currentUser?.uid,
        page: currentPage
    };
    console.error('Error logged:', errorEntry);

    // Store error logs
    const errorLogs = JSON.parse(localStorage.getItem('error_logs') || '[]');
    errorLogs.push(errorEntry);
    localStorage.setItem('error_logs', JSON.stringify(errorLogs.slice(-50))); // Keep last 50 errors
}

// Placeholder functions for future features
function addNewCar() {
    alert('Add new car functionality - TODO: Implement car management system');
}

function manageCars() {
    alert('Manage cars functionality - TODO: Implement car management interface');
}

// Handle browser back/forward
window.addEventListener('popstate', function(event) {
    if (event.state && event.state.page) {
        loadPage(event.state.page);
    }
});

// Close modals when clicking outside
window.addEventListener('click', function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});